/**
 * Author   : Sandeep
 * Project  : Multiple Choice Quiz Application Android
 * File Name: CheatActivity
 * Date     : 11/04/2015
 * Description : The CheatActivity is responsible for cheat button functionality of the User Interface
 * When a User presses the Cheat Button then the MainActivity redirects to the CheatActivity class.
 * The CheatActivity class works though the principle of getting intents from the parent class through
 * the activity manager. The CheatActivity also returns the intent through the use of the Extra which
 * acts like a key between the two activities.
 * **/
/**
 * Package Declaration and Importing of the classes
 */

package com.bignerdranch.android.myapplication;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * Class declration of the CheatActivity
 */
public class CheatActivity extends AppCompatActivity {

    private static final String EXTRA_ANSWER_IS_TRUE =
            "com.bignerdranch.android.myapplication.answer_is_true";
    private static final String EXTRA_ANSWER_SHOWN =
            "com.bignerdranch.android.myapplication.answer_shown";//Inorder to be unique
    private String mAnswer;
    private TextView mAnswerTextView;
    private Button mShowAnswer;
    private String TAG2 = "MyCheatActivity";
    /**
     * The M question.
     */
    Question mQuestion = new Question();

    /**
     * New intent intent.
     * Func Name: public static Intent newIntent
     * @param packageContext the package context
     * @param answer         the answer
     * @return intent being called for
     */
    public static Intent newIntent(Context packageContext, String answer){//String answer){
        Intent i = new Intent(packageContext, CheatActivity.class);
        i.putExtra(EXTRA_ANSWER_IS_TRUE,answer);
        return i;
    }

    /**
     *Funct name: wasAnswershown
     * Used as in cases when the user had shown the answer
     * @param result the result
     * @return the boolean
     */
    public static boolean wasAnswerShown(Intent result){
        return result.getBooleanExtra(EXTRA_ANSWER_SHOWN,false);
    }
    /**
     *Funct name: onCreate
     * The First method invoked when user presses the showAnswer button
     * @param *Savedinstance state
     * @return void
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cheat);//pops up the cheat activity xml file
        mAnswer = getIntent().getStringExtra(EXTRA_ANSWER_IS_TRUE);//gets the answer from the MainActivity
        mAnswerTextView = (TextView) findViewById(R.id.answer_text_view);
        mShowAnswer = (Button) findViewById(R.id.show_answer_button);
        mShowAnswer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG2, mAnswer);//for internal
                mAnswerTextView.setText(mAnswer);//set the text in the text view for the answer
                setAnswerShownResult(true);
            }
        });
    }

    /**
     * This function helps to send the data back to the MainActivity
     * @return void
     * @param **isAnswerShown
     */
    private void setAnswerShownResult(boolean isAnswerShown){
        Intent data = new Intent();
        data.putExtra(EXTRA_ANSWER_SHOWN, isAnswerShown);
        setResult(RESULT_OK, data);
    }

    /**
     * @param menu
     * @return boolean
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_cheat, menu);
        return true;
    }

    /**
     *
     * @param item
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
