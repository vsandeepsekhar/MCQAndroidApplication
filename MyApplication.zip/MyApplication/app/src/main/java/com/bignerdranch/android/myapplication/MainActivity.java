/**
 * Author   : Sandeep
 * Project  : Multiple Choice Quiz Application Android
 * File Name: MainActivity
 * Date     : 11/04/2015
 * Description : The MainActivity is the Superior control function for the entire application of multiple choice quiz.
 * It controls the inflating of the User Interface.. Initializes the buttons texts
 * gets the input from the Buttons. Process the Buttons and executes according to the inputs from the user.
 * and finally shows the output to the user as in how many questions were correct according to the given inputs.
 * **/
/**
 * Package and Imports
 */
package com.bignerdranch.android.myapplication;
import android.app.Activity;
import android.content.Intent;
import android.nfc.Tag;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * The type Main activity.
 */
public class MainActivity extends AppCompatActivity {

    private RadioGroup radioGroup;
    private Button mNextButton;
    private Button mCheatButton;
    private TextView tv;
    private String TAG = "MainActivity";
    private String TAG1 = "NextButton";
    /**
     * The constant KEY_INDEX.
     */
    public static final String KEY_INDEX = "index";

    private static String str1;
    private static String str2;
    private static String str3;
    private static String str4;
    private static  int counter;
    private static int mCurrentIndex=0;
    private boolean mIsCheater;
    private static final int REQUEST_CODE_CHEAT = 0;
    private TextView mQuestionTextView;
    private TextView mResultTextView;
    private Question mQuestionBank = new Question();

    /**
     * The main entry point when the application starts is onCreate
     * It is responsible for blowing the view and giving the user the
     * chance to give the inputs.
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);//main xml file floated
        //initializing variables
        mQuestionBank.setOptions();
        updateOptions();//options are floated
        mQuestionTextView = (TextView) findViewById(R.id.question_text_view);
        updateQuestion();//This is required for the first question to be shown irrespective of the button pressed

        radioGroup=(RadioGroup)findViewById(R.id.radioGroup);

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {//radio groups basic operations
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                // checkedId is the RadioButton selected
                RadioButton rb = (RadioButton) findViewById(checkedId);
                String str = (String) rb.getText();
                if(mIsCheater){//if the user cheats this flag is set
                    Toast.makeText(getApplicationContext(),"Cheating is Wrong",Toast.LENGTH_SHORT).show();
                }

                else{//if the flag is not set then answer from the radio buttons are checked to match with the answers from the Question class
                    if (str.equals(mQuestionBank.getAnswer(mCurrentIndex))) {
                        counter++;//the correct answered questions are incremented
                        Log.d(TAG1, String.valueOf(counter));
                        Toast.makeText(getApplicationContext(), "Correct Answer", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getApplicationContext(), "Wrong Answer", Toast.LENGTH_SHORT).show();
                    }
                }

                Log.d(TAG, str + "Inside MainActivity");
                tv = (TextView) findViewById(R.id.textViewChoice);
                tv.setText("You Selected " + rb.getText());
                //Toast.makeText(getApplicationContext(), rb.getText(), Toast.LENGTH_SHORT).show();
            }
        });

        //after pressing the Next Button abstract inner class called
        mNextButton = (Button) findViewById(R.id.next_button);
        mNextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (mCurrentIndex < 4) {
                    mCurrentIndex = (mCurrentIndex + 1) % mQuestionBank.length_question;
                    mIsCheater = false;
                    Log.d(TAG, String.valueOf(mCurrentIndex));
                    updateOptions();//options are updated
                    RadioButton rb = (RadioButton) findViewById(R.id.radiobutton1);
                    rb = (RadioButton) findViewById(R.id.radiobutton1);
                    rb.setText(str1);//option 1 is updated
                    rb = (RadioButton) findViewById(R.id.radiobutton2);
                    rb.setText(str2);//option 2 is updated
                    rb = (RadioButton) findViewById(R.id.radiobutton3);
                    rb.setText(str3);
                    rb = (RadioButton) findViewById(R.id.radiobutton4);
                    rb.setText(str4);
                    updateQuestion();
                } else {
                    setContentView(R.layout.activity_answer);
                    mResultTextView = (TextView) findViewById(R.id.AnswerTextView);
                    mResultTextView.setText("Results Time");
                    mResultTextView = (TextView) findViewById(R.id.NumberOfQuestion);
                    mResultTextView.setText("Number of Questions attended : 5");
                    mResultTextView = (TextView) findViewById(R.id.CorrectAnswer);
                    mResultTextView.setText("Number of Correct answers: " + counter);
                    mNextButton.setEnabled(false);//here the next button is disabled so that we cant go forward
                    Button btn1 = (Button) findViewById(R.id.ExitButton);
                    btn1.setOnClickListener(new View.OnClickListener() {

                        @Override
                        public void onClick(View v) {
                            // TODO Auto-generated method stub
                            finish();
                            System.exit(0);//The exit buttons implecit method after the exit button is clicked
                        }
                    });
                }

            }
        });

        mCheatButton = (Button) findViewById(R.id.CheatButton);
        mCheatButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String answer = mQuestionBank.getAnswer(mCurrentIndex);
                Intent i = CheatActivity.newIntent(MainActivity.this, answer);//This intent is th emedium of commuication between the cheatactivity and the Main Activity
                //startActivity(i);
                startActivityForResult(i, REQUEST_CODE_CHEAT);
            }
        });//This is invoked when the devide is rotated
        if(savedInstanceState != null){
            mCurrentIndex = savedInstanceState.getInt(KEY_INDEX,0);//return the value pointed by KEY_INDEX as a key
            RadioButton rb = (RadioButton) findViewById(R.id.radiobutton1);
            rb = (RadioButton) findViewById(R.id.radiobutton1);
            rb.setText(str1);
            rb = (RadioButton) findViewById(R.id.radiobutton2);
            rb.setText(str2);
            rb = (RadioButton) findViewById(R.id.radiobutton3);
            rb.setText(str3);
            rb = (RadioButton) findViewById(R.id.radiobutton4);
            rb.setText(str4);
            //Else in failure case return 0
        }
        updateQuestion();
    }

    /**
     * This method decides the fate of the mIsCheater if the answer is shown in the CheatActivity class or not
     * @param requestCode
     * @param resultCode
     * @param data
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        if(resultCode != Activity.RESULT_OK){
            return;
        }
        if(requestCode == REQUEST_CODE_CHEAT){
            if(data == null){
                return;
            }
            mIsCheater = CheatActivity.wasAnswerShown(data);
        }
    }

    /**
     *
     * @param savedInstanceState
     */
    @Override
    public void onSaveInstanceState(Bundle savedInstanceState){
        super.onSaveInstanceState(savedInstanceState);//calling activities onSaveInstanceState
        Log.i(TAG,"onSaveInstanceState");//log display of the saved instance state
        savedInstanceState.putInt(KEY_INDEX,mCurrentIndex);//stores the current index of the question

    }

    /**
     *
     * @param menu
     * @return
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    /**
     *
     * @param item
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * Updates the question in the Question text view in the activity_main.xml file
     */
    private void updateQuestion(){
        String question = mQuestionBank.getQuestion(mCurrentIndex);
        mQuestionTextView.setText(question);
    }

    /**
     * takes the options from the arraylist of the Question class
     */
    private void updateOptions(){
        if(mCurrentIndex > 0)
        {
            ArrayList<String> ar = mQuestionBank.getQuestionOptions(mCurrentIndex);
            str1 = ar.get(0);
            str2 = ar.get(1);
            str3 = ar.get(2);
            str4 = ar.get(3);

        }
        else{

        }
    }

    @Override
    public void onStart(){
        super.onStart();
        Log.d(TAG, "onStart() Called");
    }
    @Override
    public void onPause(){
        super.onPause();
        Log.d(TAG, "onPause() Called");
    }
    @Override
    public void onResume(){
        super.onResume();
        Log.d(TAG, "onResume() Called");
    }
    @Override
    public void onStop(){
        super.onStop();
        Log.d(TAG, "onStop() Called");
    }
    @Override
    public void onDestroy(){
        super.onDestroy();
        Log.d(TAG, "onDestroy() called");
    }
}
