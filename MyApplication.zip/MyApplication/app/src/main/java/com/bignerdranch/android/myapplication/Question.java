/**
 * Author   : Sandeep
 * Project  : Multiple Choice Quiz Application Android
 * Date     : 11/04/2015
 * File Name: Question
 * Description : The Question Class is designed to have a database of the entire Questions and Answers to be fetched by the MainActivity class
 * **/



package com.bignerdranch.android.myapplication;

import java.util.ArrayList;

public class Question {

    //All the Questions of this class are declared
    private String question[] ={ "In Which state the capital of United States Located?",
            "In Which state the capital of India is Located?",
            "What is the capital of Singapore?",
            "What is the capital of Japan?",
            "What is the capital of China?"};
    /**
     * The Length question.
     */
    public int length_question = question.length;
    /**
     * The Answer.
     */
    public String answer[] = {"Washington.D.C","Delhi","City of Singapore","Tokyo","Beijing"};// Answers are declared
    // All the ArrayList for storing the options are declared
    private ArrayList<String> question1_options = new ArrayList<String>();
    private ArrayList<String> question2_options = new ArrayList<String>();
    private ArrayList<String> question3_options = new ArrayList<String>();
    private ArrayList<String> question4_options = new ArrayList<String>();
    private ArrayList<String> question5_options = new ArrayList<String>();

    /**
     * Returns void
     *
     * @return void Adds the option to the corresponding Array List objects for the specified Questions
     * @parameter void
     */
    void setOptions()
    {
        question1_options.add("Washington");
        question1_options.add("Oregon");
        question1_options.add("NewYork");
        question1_options.add("Washington.D.C");
        question2_options.add("Odisha");
        question2_options.add("Andhra Pradesh");
        question2_options.add("Delhi");
        question2_options.add("Telangana");
        question3_options.add("Singapore");
        question3_options.add("City of Singapore");
        question3_options.add("Singapore City");
        question3_options.add("Republic of Singapore");
        question4_options.add("Tokyo");
        question4_options.add("Fukushima");
        question4_options.add("Hirosima");
        question4_options.add("Nagasaki");
        question5_options.add("Shanghai");
        question5_options.add("Beijing");
        question5_options.add("Guangzhou");
        question5_options.add("Tianjin");
    }

    /**
     * Returns the Question at the specified nextQuestion
     *
     * @param nextQuestion the next question
     * @return String with the specified index(nextQuestion).Returns null if the index is out of range
     * @parameter nextQuestion – item number of the question
     */

    String getQuestion(int nextQuestion)
    {
        return question[nextQuestion];
    }

    /**
     * Returns the ArrayList of String type at the specified nextOption
     *
     * @param nextOption the next option
     * @return ArrayList<String>  with the specified nextOption of options type.Returns null if the index is out of range
     * @parameter nextoption – item number of the next Question Options
     */
    ArrayList<String> getQuestionOptions(int nextOption)
    {
        ArrayList <String> option = new ArrayList<String>();// Create an array List object
        // Based on the value of the next option the corresponding questions option
        //ArrayList are returned
        if(nextOption == 0)
        {
            option = question1_options;
        }
        if(nextOption == 1)
        {
            option = question2_options;
        }
        if(nextOption == 2)
        {
            option = question3_options;
        }
        if(nextOption == 3)
        {
            option = question4_options;
        }
        if(nextOption == 4)
        {
            option = question5_options;
        }
        return option;

    }

    /**
     * Returns the Integer at the specified nextAnswer
     *
     * @param nextAnswer the next answer
     * @return integer with the specified nextAnswer in the answer Array.Returns null if the index is out of range
     * @parameter nextAnswer – item number at the nextAnswer value
     */
    String getAnswer(int nextAnswer)
    {
        return answer[nextAnswer];
    }
}
